INSTRUCCIONES:

El proyecto está desarrollado con JavaScript y una GUI con HTML 
por lo que cuenta una arquitectura muy simple:

- src/index.js: Archivo con toda la lógica para este proyecto
- index.html: Archivo de ejecución desde un navegador de Internet

El proyecto también está desplegado en la nube en el siguiente dominio:
https://juego-vida.web.app/

JUSTIFICACIÓN:

Elegí JavaScript como lenguaje de programación para este proyecto 
debido a que me permite una interacción desde la web con facilidad 
y es lo que pretendía hacer; además de implementarlo dentro de la nube
